import 'package:flutter/material.dart';

class ProgramDetailsScreen extends StatelessWidget {
  const ProgramDetailsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar( 
        leading: IconButton(
          icon: const Icon(Icons.arrow_back),
          onPressed: (){
            Navigator.pop(context);
          },
        ),     

        title: const Text("Program Details"),
        centerTitle: true,
        
               
      ),

      body: SingleChildScrollView(
        padding: const EdgeInsets.all(20),

        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [

            // Internship Image Placeholder
            Container(
              height: 180,
              width: double.infinity,
              decoration: BoxDecoration(
                color: Colors.grey.shade300,
                borderRadius: BorderRadius.circular(12),
              ),

              child: const Icon(
                Icons.school,
                size: 50,
                color: Colors.grey,
              ),
            ),

            const SizedBox(height: 20),

            const Text(
              "Software Development Internship",
              style: TextStyle(
                fontSize: 24,
                fontWeight: FontWeight.bold,
              ),
            ),

            const SizedBox(height: 10),

            Row(
              children: const [
                Icon(Icons.location_on, color: Color.fromARGB(255, 255, 13, 0)),
                SizedBox(width: 8),
                Text("Johannesburg"),
              ],
            ),

            const SizedBox(height: 10),

            Row(
              children: const [
                Icon(Icons.access_time, color: Colors.blue),
                SizedBox(width: 8),
                Text("Duration: 6 Months"),
              ],
            ),

            const SizedBox(height: 25),

            const Text(
              "Program Description",
              style: TextStyle(
                fontSize: 20,
                fontWeight: FontWeight.bold,
              ),
            ),

            const SizedBox(height: 10),

            const Text(
              "Gain practical experience through industry projects while developing your Flutter, Dart, GitHub and Agile development skills.",
              style: TextStyle(fontSize: 16),
            ),

            const SizedBox(height: 25),

            const Text(
              "Requirements",
              style: TextStyle(
                fontSize: 20,
                fontWeight: FontWeight.bold,
              ),
            ),

            const SizedBox(height: 10),

            const Text("• Basic programming knowledge"),
            const Text("• Laptop with internet access"),
            const Text("• Good communication skills"),
            const Text("• Passion for learning"),

            const SizedBox(height: 35),

            SizedBox(
              width: double.infinity,

              child: ElevatedButton(
                onPressed: () {},

                style: ElevatedButton.styleFrom(
                  padding: const EdgeInsets.symmetric(vertical: 16),
                ),

                child: const Text(
                  "Apply Now",
                  style: TextStyle(fontSize: 18),
                ),
              ),
            ),

            SizedBox(
              width: double.infinity,

              child: ElevatedButton(
                onPressed: () {},

                style: ElevatedButton.styleFrom(
                  padding: const EdgeInsets.symmetric(vertical: 16),
                ),

                child: const Text(
                  "Leave Review",
                  style: TextStyle(fontSize: 18),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}